Please read ALL function files(make sure to check bridge folder)
make sure to replace any of my info with yours
make sure to disable any functions you would not like in your server 

DO NOT SELL THIS PRODUCT AS YOUR OWN!
This product was made and is owned by: Vesuvius Network!
We will take immidiate action if you try to sell our product, or steal our product!
Any big changes made(adding your own functions and fixing issues) must be informed to D4Rk Akuma#7759 on discord!